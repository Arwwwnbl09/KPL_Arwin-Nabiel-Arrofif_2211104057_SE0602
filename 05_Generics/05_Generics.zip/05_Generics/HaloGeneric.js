class HaloGeneric {
    constructor() { }

    SapaUser(user) {
        console.log(`Halo Bang ${user}`);
    }
}

module.exports = HaloGeneric;
